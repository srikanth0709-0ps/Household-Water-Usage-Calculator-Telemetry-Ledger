"""Entry point for Project #44: Water Usage Calculator (DataSpark Challenge)."""

from __future__ import annotations

import argparse

from water_calculator.analytics import compute_executive_summary, format_executive_summary
from water_calculator.cli import EXPORTS_DIR, run_interactive_cli
from water_calculator.exporter import (
    export_markdown_report,
    export_standard_csv,
    export_text_audit_log,
)
from water_calculator.plotting import export_visual_charts
from water_calculator.storage import DEFAULT_CSV_PATH, DEFAULT_JSON_PATH, SAMPLE_JSON_PATH, initialize_storage


def build_arg_parser() -> argparse.ArgumentParser:
    """Create CLI argument parser supporting interactive mode and batch utilities."""
    parser = argparse.ArgumentParser(
        description="Project #44: Water Usage Calculator — Household Water Estimation & Analytics CLI"
    )
    parser.add_argument(
        "--summary",
        action="store_true",
        help="Print executive summary and threshold warnings non-interactively and exit.",
    )
    parser.add_argument(
        "--export",
        action="store_true",
        help="Export Markdown, plain-text audit log, and CSV reports into exports/ and exit.",
    )
    parser.add_argument(
        "--plot",
        action="store_true",
        help="Generate visual charts (Matplotlib or SVG/ASCII fallback) into exports/charts/ and exit.",
    )
    return parser


def main() -> None:
    """Dispatch CLI command flags or launch the interactive terminal interface."""
    args = build_arg_parser().parse_args()

    if args.summary or args.export or args.plot:
        records, notices = initialize_storage(
            json_path=DEFAULT_JSON_PATH,
            csv_path=DEFAULT_CSV_PATH,
            seed_path=SAMPLE_JSON_PATH,
        )
        for notice in notices:
            print(f"[Storage Notice] {notice}")

        summary = compute_executive_summary(records)
        if args.summary:
            print(format_executive_summary(summary))
        if args.export:
            md_path = export_markdown_report(summary, records, EXPORTS_DIR / "water_usage_summary.md")
            txt_path = export_text_audit_log(summary, records, EXPORTS_DIR / "water_usage_audit.txt")
            csv_path = export_standard_csv(records, EXPORTS_DIR / "water_usage_export.csv")
            print(f"Exported reports:\n  - {md_path}\n  - {txt_path}\n  - {csv_path}")
        if args.plot:
            paths, preview = export_visual_charts(records, EXPORTS_DIR / "charts")
            print(preview)
            for path in paths:
                print(f"Chart written: {path}")
        return

    run_interactive_cli()


if __name__ == "__main__":
    main()
