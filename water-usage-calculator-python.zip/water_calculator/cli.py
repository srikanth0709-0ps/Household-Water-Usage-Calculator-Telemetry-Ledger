"""Interactive ANSI-formatted Terminal Interface for Project #44: Water Usage Calculator."""

from __future__ import annotations

import datetime
from pathlib import Path
from typing import Callable

from .analytics import compute_executive_summary, format_executive_summary
from .engine import ACTIVITY_PROFILES, create_water_record, next_record_id
from .exporter import (
    bulk_import_csv,
    export_markdown_report,
    export_standard_csv,
    export_text_audit_log,
)
from .models import WaterRecord
from .plotting import export_visual_charts
from .query import filter_records, format_records_table, paginate_records, sort_records
from .storage import (
    BASE_DIR,
    DEFAULT_CSV_PATH,
    DEFAULT_JSON_PATH,
    SAMPLE_JSON_PATH,
    initialize_storage,
    load_records_json,
    sync_all_stores,
)
from .validation import (
    prompt_menu_choice,
    prompt_with_validator,
    sanitize_notes,
    validate_activity,
    validate_date,
    validate_household_id,
    validate_quantity,
)

EXPORTS_DIR = BASE_DIR / "exports"

ANSI_CYAN = "\033[96m"
ANSI_BLUE = "\033[94m"
ANSI_GREEN = "\033[92m"
ANSI_YELLOW = "\033[93m"
ANSI_RED = "\033[91m"
ANSI_BOLD = "\033[1m"
ANSI_RESET = "\033[0m"


def print_banner(output_fn: Callable[[str], None] = print) -> None:
    """Display branded terminal welcome banner."""
    output_fn(f"\n{ANSI_BOLD}{ANSI_CYAN}+--------------------------------------------------------------+{ANSI_RESET}")
    output_fn(f"{ANSI_BOLD}{ANSI_CYAN}|   DataSpark Challenge · Project #44: Water Usage Calculator  |{ANSI_RESET}")
    output_fn(f"{ANSI_BOLD}{ANSI_CYAN}|   Environment & Sustainability | Local JSON/CSV Persistence  |{ANSI_RESET}")
    output_fn(f"{ANSI_BOLD}{ANSI_CYAN}+--------------------------------------------------------------+{ANSI_RESET}")


def print_menu(record_count: int, output_fn: Callable[[str], None] = print) -> None:
    """Render primary interactive menu options."""
    output_fn(f"\n{ANSI_BOLD}{ANSI_BLUE}Main Menu ({record_count} stored records):{ANSI_RESET}")
    output_fn("  1. Log New Water Usage Activity (Defensive Input Validation)")
    output_fn("  2. View All Records (Fixed-Width Paginated Table)")
    output_fn("  3. Search & Filter Records (Keyword / Category / Status)")
    output_fn("  4. Executive Summary & Threshold Warning Indicators")
    output_fn("  5. Visual Data Plotting (Matplotlib / ASCII-SVG Fallback)")
    output_fn("  6. Export Summary Reports (Markdown, Audit Log, CSV)")
    output_fn("  7. Bulk Import Legacy CSV (Row-by-Row Error Audit)")
    output_fn("  8. Reset to 36 Seeded Sample Records")
    output_fn("  9. Save & Exit")


def handle_log_entry(
    records: list[WaterRecord],
    json_path: Path,
    csv_path: Path,
    input_fn: Callable[[str], str] = input,
    output_fn: Callable[[str], None] = print,
) -> list[WaterRecord]:
    """Guided workflow for logging a validated household water usage entry."""
    output_fn(f"\n{ANSI_BOLD}--- Log New Water Usage Entry ---{ANSI_RESET}")
    today_default = datetime.date.today().isoformat()
    date_str = prompt_with_validator(
        f"  Date [YYYY-MM-DD, Enter for {today_default}]: ",
        validate_date,
        input_fn=input_fn,
        output_fn=output_fn,
        default_value=today_default,
    )
    household_id = prompt_with_validator(
        "  Household ID [HH-01..HH-99]: ",
        validate_household_id,
        input_fn=input_fn,
        output_fn=output_fn,
    )

    output_fn("  Available Activities:")
    for idx, (name, profile) in enumerate(ACTIVITY_PROFILES.items(), start=1):
        output_fn(
            f"    {idx}. {name:<12} ({profile.flow_rate_liters_per_unit:.1f} L/{profile.unit}, safe cap {profile.max_safe_quantity:.0f})"
        )

    activity = prompt_with_validator(
        "  Select Activity (name or 1-6): ",
        validate_activity,
        input_fn=input_fn,
        output_fn=output_fn,
    )
    unit = ACTIVITY_PROFILES[activity].unit
    quantity = prompt_with_validator(
        f"  Quantity ({unit}): ",
        lambda raw: validate_quantity(raw, activity),
        input_fn=input_fn,
        output_fn=output_fn,
    )
    raw_notes = input_fn("  Optional Audit Notes: ")
    notes = sanitize_notes(raw_notes, default=f"{activity} daily entry")

    rec_id = next_record_id(records)
    new_record = create_water_record(
        record_id=rec_id,
        date_str=date_str,
        household_id=household_id,
        activity=activity,
        quantity=quantity,
        notes=notes,
    )
    updated = [new_record, *records]
    sync_all_stores(updated, json_path=json_path, csv_path=csv_path)

    status_color = (
        ANSI_RED
        if new_record.status == "Critical Breach"
        else ANSI_YELLOW
        if new_record.status == "Elevated"
        else ANSI_GREEN
    )
    output_fn(
        f"\n  {ANSI_GREEN}[Saved]{ANSI_RESET} {new_record.id} | {new_record.estimated_liters:.1f} L | "
        f"Status: {status_color}{new_record.status}{ANSI_RESET} | Synced to JSON & CSV."
    )
    return updated


def handle_view_records(
    records: list[WaterRecord],
    input_fn: Callable[[str], str] = input,
    output_fn: Callable[[str], None] = print,
) -> None:
    """Display sorted, paginated tabular records."""
    ordered = sort_records(records, sort_by="date", descending=True)
    page = 1
    page_size = 12
    while True:
        output_fn("")
        output_fn(format_records_table(ordered, page=page, page_size=page_size))
        _, safe_page, total_pages = paginate_records(ordered, page=page, page_size=page_size)
        if total_pages <= 1:
            break
        nav = input_fn("  Pagination [N]ext, [P]revious, or [Enter] to return: ").strip().lower()
        if nav == "n" and safe_page < total_pages:
            page = safe_page + 1
        elif nav == "p" and safe_page > 1:
            page = safe_page - 1
        else:
            break


def handle_search_records(
    records: list[WaterRecord],
    input_fn: Callable[[str], str] = input,
    output_fn: Callable[[str], None] = print,
) -> None:
    """Filter records by keyword, activity category, or threshold status."""
    output_fn(f"\n{ANSI_BOLD}--- Search & Filter Records ---{ANSI_RESET}")
    keyword = input_fn("  Keyword (ID, household, notes, or Enter for all): ").strip()
    activity_raw = input_fn("  Activity filter (Shower/Laundry/Dishwashing/Garden/Kitchen/Toilet or Enter): ").strip()
    status_raw = input_fn("  Status filter (Nominal/Elevated/Critical Breach or Enter): ").strip()

    matched = filter_records(
        records,
        keyword=keyword,
        activity=activity_raw or None,
        status=status_raw or None,
    )
    ordered = sort_records(matched, sort_by="estimated_liters", descending=True)
    output_fn("")
    output_fn(format_records_table(ordered, page=1, page_size=15))


def handle_executive_summary(
    records: list[WaterRecord],
    output_fn: Callable[[str], None] = print,
) -> None:
    """Compute and print executive metrics and threshold warnings."""
    summary = compute_executive_summary(records)
    output_fn("")
    output_fn(format_executive_summary(summary))


def handle_visual_plots(
    records: list[WaterRecord],
    output_dir: Path = EXPORTS_DIR / "charts",
    output_fn: Callable[[str], None] = print,
) -> None:
    """Generate Matplotlib/SVG charts and display ASCII visualization preview."""
    paths, preview = export_visual_charts(records, output_dir)
    output_fn("")
    output_fn(preview)
    if paths:
        output_fn(f"\n  {ANSI_GREEN}[Charts Exported]{ANSI_RESET}")
        for path in paths:
            output_fn(f"    -> {path}")


def handle_export_reports(
    records: list[WaterRecord],
    output_dir: Path = EXPORTS_DIR,
    output_fn: Callable[[str], None] = print,
) -> None:
    """Export Markdown summary, plain-text audit log, and standardized CSV."""
    summary = compute_executive_summary(records)
    md_path = export_markdown_report(summary, records, output_dir / "water_usage_summary.md")
    txt_path = export_text_audit_log(summary, records, output_dir / "water_usage_audit.txt")
    csv_path = export_standard_csv(records, output_dir / "water_usage_export.csv")
    output_fn(f"\n  {ANSI_GREEN}[Reports Generated]{ANSI_RESET}")
    output_fn(f"    Markdown Summary : {md_path}")
    output_fn(f"    Plain-Text Audit : {txt_path}")
    output_fn(f"    Standardized CSV : {csv_path}")


def handle_bulk_import(
    records: list[WaterRecord],
    json_path: Path,
    csv_path: Path,
    input_fn: Callable[[str], str] = input,
    output_fn: Callable[[str], None] = print,
) -> list[WaterRecord]:
    """Ingest external legacy CSV file with row-by-row validation log."""
    output_fn(f"\n{ANSI_BOLD}--- Bulk CSV Dataset Import ---{ANSI_RESET}")
    raw_path = input_fn("  Path to CSV file (e.g., data/sample_water_usage.csv): ").strip()
    if not raw_path:
        output_fn("  Import cancelled (no path provided).")
        return records

    result = bulk_import_csv(Path(raw_path), records)
    if result.imported_count > 0:
        updated = [*result.records, *records]
        sync_all_stores(updated, json_path=json_path, csv_path=csv_path)
    else:
        updated = records

    output_fn(
        f"  {ANSI_GREEN}Imported: {result.imported_count}{ANSI_RESET} | "
        f"{ANSI_YELLOW}Skipped: {result.skipped_count}{ANSI_RESET}"
    )
    for err in result.error_logs[:10]:
        output_fn(f"    {ANSI_RED}[Row Error]{ANSI_RESET} {err}")
    return updated


def run_interactive_cli(
    json_path: Path = DEFAULT_JSON_PATH,
    csv_path: Path = DEFAULT_CSV_PATH,
    seed_path: Path = SAMPLE_JSON_PATH,
    input_fn: Callable[[str], str] = input,
    output_fn: Callable[[str], None] = print,
) -> None:
    """Primary interactive terminal dispatch loop."""
    print_banner(output_fn=output_fn)
    records, notices = initialize_storage(
        json_path=json_path,
        csv_path=csv_path,
        seed_path=seed_path,
    )
    for notice in notices:
        output_fn(f"  {ANSI_YELLOW}[Storage Notice]{ANSI_RESET} {notice}")

    valid_choices = {"1", "2", "3", "4", "5", "6", "7", "8", "9"}
    try:
        while True:
            print_menu(len(records), output_fn=output_fn)
            choice = prompt_menu_choice(
                "Select option [1-9]: ",
                valid_choices,
                input_fn=input_fn,
                output_fn=output_fn,
            )

            if choice == "1":
                records = handle_log_entry(records, json_path, csv_path, input_fn, output_fn)
            elif choice == "2":
                handle_view_records(records, input_fn, output_fn)
            elif choice == "3":
                handle_search_records(records, input_fn, output_fn)
            elif choice == "4":
                handle_executive_summary(records, output_fn)
            elif choice == "5":
                handle_visual_plots(records, output_fn=output_fn)
            elif choice == "6":
                handle_export_reports(records, output_fn=output_fn)
            elif choice == "7":
                records = handle_bulk_import(records, json_path, csv_path, input_fn, output_fn)
            elif choice == "8":
                records, _ = load_records_json(seed_path, seed_fallback_path=seed_path)
                sync_all_stores(records, json_path=json_path, csv_path=csv_path)
                output_fn(f"  {ANSI_GREEN}[Reset]{ANSI_RESET} Restored {len(records)} sample records.")
            elif choice == "9":
                sync_all_stores(records, json_path=json_path, csv_path=csv_path)
                output_fn(
                    f"\n  {ANSI_GREEN}State preserved ({len(records)} records). Goodbye!{ANSI_RESET}\n"
                )
                break
    except (KeyboardInterrupt, EOFError):
        sync_all_stores(records, json_path=json_path, csv_path=csv_path)
        output_fn("\n  Session interrupted; state safely persisted. Exiting.")
