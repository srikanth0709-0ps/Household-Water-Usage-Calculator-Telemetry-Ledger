"""Defensive input validation routines and terminal prompt wrappers."""

from __future__ import annotations

import datetime
import math
import re
from typing import Callable, TypeVar

from .engine import ACTIVITY_PROFILES, get_activity_profile

T = TypeVar("T")

DATE_PATTERN = re.compile(r"^\d{4}-\d{2}-\d{2}$")
HOUSEHOLD_PATTERN = re.compile(r"^HH-(0[1-9]|[1-9]\d)$")


def validate_date(raw: str) -> str:
    """Validate YYYY-MM-DD format and verify it represents a real calendar date."""
    value = raw.strip()
    if not value:
        raise ValueError("Date cannot be blank. Expected format: YYYY-MM-DD (e.g., 2026-11-24).")
    if not DATE_PATTERN.match(value):
        raise ValueError(f"Invalid date format '{value}'. Expected YYYY-MM-DD (e.g., 2026-11-24).")
    try:
        datetime.date.fromisoformat(value)
    except ValueError as exc:
        raise ValueError(f"Non-existent calendar date '{value}'.") from exc
    return value


def validate_household_id(raw: str) -> str:
    """Validate household identifier matching HH-01 through HH-99."""
    value = raw.strip().upper()
    if not value:
        raise ValueError("Household ID cannot be blank. Expected format: HH-01 through HH-99.")
    if not HOUSEHOLD_PATTERN.match(value):
        raise ValueError(
            f"Invalid Household ID '{raw.strip()}'. Expected format HH-01 through HH-99."
        )
    return value


def validate_activity(raw: str) -> str:
    """Validate domestic activity category name (case-insensitive) or numeric index."""
    value = raw.strip()
    if not value:
        raise ValueError("Activity cannot be blank.")
    names = list(ACTIVITY_PROFILES.keys())
    if value.isdigit():
        idx = int(value)
        if 1 <= idx <= len(names):
            return names[idx - 1]
    return get_activity_profile(value).name


def validate_quantity(raw: str, activity: str) -> float:
    """Validate positive numeric quantity within activity-specific domain bounds."""
    value = raw.strip()
    if not value:
        raise ValueError("Quantity cannot be blank. Enter a positive number.")
    try:
        qty = float(value)
    except ValueError as exc:
        raise ValueError(f"Non-numeric quantity '{value}'. Enter a valid positive number.") from exc

    if not math.isfinite(qty) or qty <= 0:
        raise ValueError(f"Quantity ({qty}) must be strictly greater than 0.")

    profile = get_activity_profile(activity)
    if qty > profile.hard_limit_quantity:
        raise ValueError(
            f"Quantity {qty} {profile.unit} exceeds hard safety limit of "
            f"{profile.hard_limit_quantity} {profile.unit} for {profile.name}."
        )
    return round(qty, 2)


def sanitize_notes(raw: str, default: str = "") -> str:
    """Strip control characters and normalize whitespace for audit notes."""
    cleaned = re.sub(r"[\r\n\t]+", " ", raw).strip()
    cleaned = re.sub(r"\s{2,}", " ", cleaned)
    if not cleaned:
        return default
    return cleaned[:160]


def prompt_with_validator(
    prompt_text: str,
    validator: Callable[[str], T],
    input_fn: Callable[[str], str] = input,
    output_fn: Callable[[str], None] = print,
    default_value: str | None = None,
) -> T:
    """Centralized input loop catching ValueError until a conforming entry is supplied."""
    while True:
        raw = input_fn(prompt_text)
        if not raw.strip() and default_value is not None:
            raw = default_value
        try:
            return validator(raw)
        except ValueError as err:
            output_fn(f"  [Validation Error] {err} Please try again.")


def prompt_menu_choice(
    prompt_text: str,
    valid_choices: set[str],
    input_fn: Callable[[str], str] = input,
    output_fn: Callable[[str], None] = print,
) -> str:
    """Prompt until user enters one of the permitted menu option keys."""
    def _check(raw: str) -> str:
        choice = raw.strip()
        if choice not in valid_choices:
            sorted_opts = ", ".join(sorted(valid_choices))
            raise ValueError(f"Invalid selection '{choice}'. Choose one of: {sorted_opts}.")
        return choice

    return prompt_with_validator(prompt_text, _check, input_fn=input_fn, output_fn=output_fn)
