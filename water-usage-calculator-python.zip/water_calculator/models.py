"""Data models and typed schemas for Project #44: Water Usage Calculator."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from typing import Any


@dataclass(frozen=True)
class ActivityProfile:
    """Calibrated hydrological profile for a domestic water activity."""

    name: str
    unit: str
    flow_rate_liters_per_unit: float
    max_safe_quantity: float
    hard_limit_quantity: float


@dataclass
class WaterRecord:
    """Represents a single validated household water consumption entry."""

    id: str
    date: str
    household_id: str
    activity: str
    quantity: float
    unit: str
    flow_rate_liters_per_unit: float
    estimated_liters: float
    case_type: str
    status: str
    notes: str = ""

    def to_dict(self) -> dict[str, Any]:
        """Serialize record to JSON-compatible dictionary."""
        return asdict(self)

    def to_csv_dict(self) -> dict[str, Any]:
        """Serialize record with camelCase keys compatible with web/CSV schemas."""
        return {
            "id": self.id,
            "date": self.date,
            "householdId": self.household_id,
            "activity": self.activity,
            "quantity": self.quantity,
            "unit": self.unit,
            "flowRateLitersPerUnit": self.flow_rate_liters_per_unit,
            "estimatedLiters": self.estimated_liters,
            "caseType": self.case_type,
            "status": self.status,
            "notes": self.notes,
        }

    @classmethod
    def from_dict(cls, payload: dict[str, Any]) -> "WaterRecord":
        """Deserialize a WaterRecord from either snake_case or camelCase dictionary keys."""
        household = payload.get("household_id", payload.get("householdId"))
        flow_rate = payload.get("flow_rate_liters_per_unit", payload.get("flowRateLitersPerUnit"))
        estimated = payload.get("estimated_liters", payload.get("estimatedLiters"))
        case_type = payload.get("case_type", payload.get("caseType", "Normal"))

        required = {
            "id": payload.get("id"),
            "date": payload.get("date"),
            "household_id": household,
            "activity": payload.get("activity"),
            "quantity": payload.get("quantity"),
            "unit": payload.get("unit"),
            "flow_rate_liters_per_unit": flow_rate,
            "estimated_liters": estimated,
            "status": payload.get("status"),
        }
        missing = [key for key, value in required.items() if value is None or value == ""]
        if missing:
            raise ValueError(f"Missing required WaterRecord fields: {', '.join(missing)}")

        return cls(
            id=str(required["id"]).strip(),
            date=str(required["date"]).strip(),
            household_id=str(required["household_id"]).strip().upper(),
            activity=str(required["activity"]).strip(),
            quantity=round(float(required["quantity"]), 2),
            unit=str(required["unit"]).strip(),
            flow_rate_liters_per_unit=round(float(required["flow_rate_liters_per_unit"]), 2),
            estimated_liters=round(float(required["estimated_liters"]), 2),
            case_type=str(case_type).strip(),
            status=str(required["status"]).strip(),
            notes=str(payload.get("notes", "")).strip(),
        )


@dataclass
class BulkImportResult:
    """Result summary produced by bulk CSV ingestion."""

    imported_count: int
    skipped_count: int
    records: list[WaterRecord] = field(default_factory=list)
    error_logs: list[str] = field(default_factory=list)


@dataclass
class ExecutiveSummary:
    """Aggregated executive analytics and threshold warnings."""

    total_records: int
    unique_days: int
    total_liters: float
    average_per_entry: float
    daily_average: float
    nominal_count: int
    elevated_count: int
    critical_breach_count: int
    by_activity: list[dict[str, Any]] = field(default_factory=list)
    by_household: list[dict[str, Any]] = field(default_factory=list)
    daily_totals: list[dict[str, Any]] = field(default_factory=list)
    warnings: list[str] = field(default_factory=list)
