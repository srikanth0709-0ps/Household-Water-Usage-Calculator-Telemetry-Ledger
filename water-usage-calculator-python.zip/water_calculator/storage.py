"""Local CSV and JSON persistence with defensive corruption recovery."""

from __future__ import annotations

import csv
import json
from pathlib import Path

from .models import WaterRecord

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "data"
DEFAULT_JSON_PATH = DATA_DIR / "water_usage.json"
DEFAULT_CSV_PATH = DATA_DIR / "water_usage.csv"
SAMPLE_JSON_PATH = DATA_DIR / "sample_water_usage.json"
SAMPLE_CSV_PATH = DATA_DIR / "sample_water_usage.csv"

CSV_FIELDNAMES = [
    "id",
    "date",
    "householdId",
    "activity",
    "quantity",
    "unit",
    "flowRateLitersPerUnit",
    "estimatedLiters",
    "caseType",
    "status",
    "notes",
]


def load_records_json(
    filepath: Path = DEFAULT_JSON_PATH,
    seed_fallback_path: Path = SAMPLE_JSON_PATH,
) -> tuple[list[WaterRecord], list[str]]:
    """Load records from JSON with try-except recovery for missing or corrupted files."""
    notices: list[str] = []
    try:
        raw_text = filepath.read_text(encoding="utf-8")
        if not raw_text.strip():
            raise json.JSONDecodeError("Empty JSON file", raw_text, 0)
        payload = json.loads(raw_text)
        if not isinstance(payload, list):
            raise ValueError("JSON root must be a list of WaterRecord objects.")

        records: list[WaterRecord] = []
        for idx, item in enumerate(payload, start=1):
            if not isinstance(item, dict):
                notices.append(f"Skipped malformed JSON item at index {idx - 1}.")
                continue
            try:
                records.append(WaterRecord.from_dict(item))
            except ValueError as err:
                notices.append(f"Skipped invalid JSON record #{idx}: {err}")
        return records, notices

    except FileNotFoundError:
        notices.append(
            f"Storage file '{filepath.name}' not found. Initializing clean starter store."
        )
    except (json.JSONDecodeError, ValueError, OSError) as err:
        notices.append(
            f"Corrupted or unreadable JSON in '{filepath.name}' ({err}). Restoring clean template."
        )

    seeded = _load_seed_records(seed_fallback_path)
    save_records_json(filepath, seeded)
    return seeded, notices


def _load_seed_records(seed_path: Path) -> list[WaterRecord]:
    """Read seeded sample records safely; returns empty list if seed file is absent."""
    if not seed_path.exists():
        return []
    try:
        payload = json.loads(seed_path.read_text(encoding="utf-8"))
        if isinstance(payload, list):
            return [WaterRecord.from_dict(item) for item in payload if isinstance(item, dict)]
    except (json.JSONDecodeError, ValueError, OSError):
        return []
    return []


def save_records_json(filepath: Path, records: list[WaterRecord]) -> None:
    """Persist records cleanly to a formatted JSON file."""
    filepath.parent.mkdir(parents=True, exist_ok=True)
    serialized = [rec.to_csv_dict() for rec in records]
    filepath.write_text(json.dumps(serialized, indent=2, ensure_ascii=False) + "\n", encoding="utf-8")


def load_records_csv(filepath: Path = DEFAULT_CSV_PATH) -> tuple[list[WaterRecord], list[str]]:
    """Load structured records from CSV with row-by-row validation."""
    notices: list[str] = []
    records: list[WaterRecord] = []
    try:
        with filepath.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.DictReader(handle)
            if reader.fieldnames is None:
                notices.append(f"CSV file '{filepath.name}' is empty; created clean header template.")
                save_records_csv(filepath, [])
                return [], notices
            for row_num, row in enumerate(reader, start=2):
                try:
                    records.append(WaterRecord.from_dict(row))
                except ValueError as err:
                    notices.append(f"Skipped invalid CSV row {row_num}: {err}")
        return records, notices
    except FileNotFoundError:
        notices.append(f"CSV store '{filepath.name}' missing. Creating clean initial CSV template.")
        save_records_csv(filepath, [])
        return [], notices
    except (csv.Error, OSError) as err:
        notices.append(f"CSV read error in '{filepath.name}': {err}. Creating clean template.")
        save_records_csv(filepath, [])
        return [], notices


def save_records_csv(filepath: Path, records: list[WaterRecord]) -> None:
    """Persist structured records to CSV using Python's standard csv module."""
    filepath.parent.mkdir(parents=True, exist_ok=True)
    with filepath.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=CSV_FIELDNAMES)
        writer.writeheader()
        for rec in records:
            writer.writerow(rec.to_csv_dict())


def sync_all_stores(
    records: list[WaterRecord],
    json_path: Path = DEFAULT_JSON_PATH,
    csv_path: Path = DEFAULT_CSV_PATH,
) -> None:
    """Atomically synchronize active application state to both JSON and CSV files."""
    save_records_json(json_path, records)
    save_records_csv(csv_path, records)


def initialize_storage(
    json_path: Path = DEFAULT_JSON_PATH,
    csv_path: Path = DEFAULT_CSV_PATH,
    seed_path: Path = SAMPLE_JSON_PATH,
) -> tuple[list[WaterRecord], list[str]]:
    """Initialize local storage on startup and synchronize CSV mirror."""
    records, notices = load_records_json(json_path, seed_fallback_path=seed_path)
    if not csv_path.exists():
        save_records_csv(csv_path, records)
    return records, notices
