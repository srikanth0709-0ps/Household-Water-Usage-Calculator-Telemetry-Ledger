"""Core hydrological estimation logic and threshold classification engine."""

from __future__ import annotations

import math

from .models import ActivityProfile, WaterRecord

ELEVATED_THRESHOLD_LITERS = 140.0
CRITICAL_THRESHOLD_LITERS = 250.0

ACTIVITY_PROFILES: dict[str, ActivityProfile] = {
    "Shower": ActivityProfile(
        name="Shower",
        unit="min",
        flow_rate_liters_per_unit=9.5,
        max_safe_quantity=45.0,
        hard_limit_quantity=90.0,
    ),
    "Laundry": ActivityProfile(
        name="Laundry",
        unit="loads",
        flow_rate_liters_per_unit=54.0,
        max_safe_quantity=8.0,
        hard_limit_quantity=16.0,
    ),
    "Dishwashing": ActivityProfile(
        name="Dishwashing",
        unit="cycles",
        flow_rate_liters_per_unit=16.0,
        max_safe_quantity=6.0,
        hard_limit_quantity=12.0,
    ),
    "Garden": ActivityProfile(
        name="Garden",
        unit="min",
        flow_rate_liters_per_unit=14.0,
        max_safe_quantity=60.0,
        hard_limit_quantity=120.0,
    ),
    "Kitchen": ActivityProfile(
        name="Kitchen",
        unit="min",
        flow_rate_liters_per_unit=6.0,
        max_safe_quantity=40.0,
        hard_limit_quantity=80.0,
    ),
    "Toilet": ActivityProfile(
        name="Toilet",
        unit="flushes",
        flow_rate_liters_per_unit=6.0,
        max_safe_quantity=30.0,
        hard_limit_quantity=60.0,
    ),
}


def get_activity_profile(activity: str) -> ActivityProfile:
    """Resolve an ActivityProfile case-insensitively."""
    normalized = activity.strip().lower()
    for name, profile in ACTIVITY_PROFILES.items():
        if name.lower() == normalized:
            return profile
    supported = ", ".join(ACTIVITY_PROFILES.keys())
    raise ValueError(f"Unsupported activity '{activity}'. Expected one of: {supported}.")


def calculate_estimated_liters(activity: str, quantity: float) -> float:
    """Compute estimated household water use in liters from activity and quantity."""
    if not math.isfinite(quantity) or quantity <= 0:
        raise ValueError(f"Quantity must be a positive finite number, got {quantity!r}.")
    profile = get_activity_profile(activity)
    return round(quantity * profile.flow_rate_liters_per_unit, 1)


def classify_threshold(estimated_liters: float) -> str:
    """Assign semantic operational threshold status based on liter volume."""
    if estimated_liters >= CRITICAL_THRESHOLD_LITERS:
        return "Critical Breach"
    if estimated_liters >= ELEVATED_THRESHOLD_LITERS:
        return "Elevated"
    return "Nominal"


def classify_case_type(activity: str, quantity: float, estimated_liters: float) -> str:
    """Classify entry as Normal, Boundary, or Edge Condition."""
    profile = get_activity_profile(activity)
    if quantity <= 1.0 or math.isclose(quantity, profile.max_safe_quantity, rel_tol=1e-6):
        return "Boundary"
    if estimated_liters >= CRITICAL_THRESHOLD_LITERS or quantity > profile.max_safe_quantity:
        return "Edge Condition"
    return "Normal"


def next_record_id(existing_records: list[WaterRecord]) -> str:
    """Generate the next sequential WU-XXX record identifier."""
    max_num = 100
    for rec in existing_records:
        if rec.id.upper().startswith("WU-"):
            suffix = rec.id[3:]
            if suffix.isdigit():
                max_num = max(max_num, int(suffix))
    return f"WU-{max_num + 1}"


def create_water_record(
    record_id: str,
    date_str: str,
    household_id: str,
    activity: str,
    quantity: float,
    notes: str = "",
) -> WaterRecord:
    """Construct a complete, calculated WaterRecord from validated domain inputs."""
    profile = get_activity_profile(activity)
    estimated = calculate_estimated_liters(profile.name, quantity)
    status = classify_threshold(estimated)
    case_type = classify_case_type(profile.name, quantity, estimated)
    clean_notes = notes.strip() or f"{profile.name} daily usage entry"

    return WaterRecord(
        id=record_id.strip().upper(),
        date=date_str.strip(),
        household_id=household_id.strip().upper(),
        activity=profile.name,
        quantity=round(float(quantity), 2),
        unit=profile.unit,
        flow_rate_liters_per_unit=profile.flow_rate_liters_per_unit,
        estimated_liters=estimated,
        case_type=case_type,
        status=status,
        notes=clean_notes,
    )
