"""Visual data plotting with Matplotlib and defensive ImportError ASCII/SVG fallback."""

from __future__ import annotations

from pathlib import Path

from .analytics import compute_executive_summary
from .engine import CRITICAL_THRESHOLD_LITERS
from .models import WaterRecord


def render_ascii_charts(records: list[WaterRecord]) -> str:
    """Generate terminal-friendly ASCII bar and daily trend charts."""
    summary = compute_executive_summary(records)
    if summary.total_records == 0:
        return "  (No data available to plot.)"

    lines = ["=== VISUAL WATER USAGE DISTRIBUTION (ASCII FALLBACK) ==="]
    max_act = max((item["total_liters"] for item in summary.by_activity), default=1.0) or 1.0
    for item in summary.by_activity:
        bar_len = int(round((item["total_liters"] / max_act) * 32))
        bar = "#" * bar_len
        lines.append(
            f"{item['activity']:<12} | {bar:<32} | {item['total_liters']:>7.1f} L ({item['share_pct']:>5.1f}%)"
        )

    lines.append("")
    lines.append("=== DAILY CONSUMPTION TREND (250L CRITICAL LIMIT) ===")
    max_day = max((d["total_liters"] for d in summary.daily_totals), default=1.0) or 1.0
    for d in summary.daily_totals[-14:]:
        bar_len = int(round((d["total_liters"] / max_day) * 28))
        flag = " [BREACH]" if d["total_liters"] >= CRITICAL_THRESHOLD_LITERS else ""
        lines.append(
            f"{d['date']} | {'*' * bar_len:<28} | {d['total_liters']:>7.1f} L{flag}"
        )
    return "\n".join(lines)


def _write_fallback_svg_charts(records: list[WaterRecord], output_dir: Path) -> list[Path]:
    """Write standalone SVG charts when Matplotlib is unavailable."""
    summary = compute_executive_summary(records)
    output_dir.mkdir(parents=True, exist_ok=True)
    generated: list[Path] = []

    colors = {
        "Shower": "#0891B2",
        "Laundry": "#2563EB",
        "Dishwashing": "#4F46E5",
        "Garden": "#059669",
        "Kitchen": "#D97706",
        "Toilet": "#E11D48",
    }

    # 1. Activity distribution SVG
    max_act = max((a["total_liters"] for a in summary.by_activity), default=1.0) or 1.0
    bars_svg = []
    for idx, item in enumerate(summary.by_activity):
        y = 50 + idx * 38
        width = max(4.0, (item["total_liters"] / max_act) * 340.0)
        fill = colors.get(item["activity"], "#0891B2")
        bars_svg.append(
            f'<text x="20" y="{y + 16}" font-family="sans-serif" font-size="13" fill="#0F172A">{item["activity"]}</text>'
            f'<rect x="130" y="{y}" width="{width:.1f}" height="22" rx="4" fill="{fill}"/>'
            f'<text x="{138 + width:.1f}" y="{y + 16}" font-family="monospace" font-size="12" fill="#334155">{item["total_liters"]:.1f} L ({item["share_pct"]:.1f}%)</text>'
        )

    act_svg = (
        '<svg xmlns="http://www.w3.org/2000/svg" width="640" height="300" viewBox="0 0 640 300">'
        '<rect width="640" height="300" fill="#FFFFFF"/>'
        '<text x="20" y="30" font-family="sans-serif" font-size="16" font-weight="bold" fill="#0F172A">Water Usage by Activity</text>'
        + "".join(bars_svg)
        + "</svg>"
    )
    act_path = output_dir / "activity_distribution.svg"
    act_path.write_text(act_svg, encoding="utf-8")
    generated.append(act_path)

    # 2. Daily trend SVG
    daily = summary.daily_totals
    max_day = max([300.0] + [d["total_liters"] for d in daily])
    pts = []
    for i, d in enumerate(daily):
        x = 50 + (i / max(1, len(daily) - 1)) * 540 if len(daily) > 1 else 320
        y = 240 - (d["total_liters"] / max_day) * 180
        pts.append(f"{x:.1f},{y:.1f}")
    thresh_y = 240 - (CRITICAL_THRESHOLD_LITERS / max_day) * 180
    trend_svg = (
        '<svg xmlns="http://www.w3.org/2000/svg" width="640" height="280" viewBox="0 0 640 280">'
        '<rect width="640" height="280" fill="#FFFFFF"/>'
        '<text x="20" y="28" font-family="sans-serif" font-size="16" font-weight="bold" fill="#0F172A">Daily Water Consumption Trend</text>'
        f'<line x1="50" y1="{thresh_y:.1f}" x2="590" y2="{thresh_y:.1f}" stroke="#E11D48" stroke-dasharray="5,5" stroke-width="1.5"/>'
        f'<polyline fill="none" stroke="#0891B2" stroke-width="2.5" points="{" ".join(pts)}"/>'
        "</svg>"
    )
    trend_path = output_dir / "daily_consumption_trend.svg"
    trend_path.write_text(trend_svg, encoding="utf-8")
    generated.append(trend_path)
    return generated


def export_visual_charts(
    records: list[WaterRecord],
    output_dir: Path,
) -> tuple[list[Path], str]:
    """Generate trend and distribution plots using Matplotlib with ImportError fallback."""
    ascii_preview = render_ascii_charts(records)
    summary = compute_executive_summary(records)
    if summary.total_records == 0:
        return [], ascii_preview

    try:
        import matplotlib

        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        output_dir.mkdir(parents=True, exist_ok=True)
        exported_paths: list[Path] = []

        # 1. Activity Distribution Bar Chart
        activities = [a["activity"] for a in summary.by_activity]
        liters = [a["total_liters"] for a in summary.by_activity]
        palette = ["#0891B2", "#2563EB", "#4F46E5", "#059669", "#D97706", "#E11D48"]

        fig, ax = plt.subplots(figsize=(8, 4.5))
        ax.barh(activities, liters, color=palette[: len(activities)])
        ax.invert_yaxis()
        ax.set_xlabel("Estimated Water Consumed (Liters)")
        ax.set_title("Water Usage Calculator — Activity Distribution")
        ax.grid(axis="x", linestyle="--", alpha=0.4)
        fig.tight_layout()
        dist_path = output_dir / "activity_distribution.png"
        fig.savefig(dist_path, dpi=150)
        plt.close(fig)
        exported_paths.append(dist_path)

        # 2. Daily Consumption Trend Plot
        dates = [d["date"] for d in summary.daily_totals]
        daily_vals = [d["total_liters"] for d in summary.daily_totals]

        fig2, ax2 = plt.subplots(figsize=(9, 4.5))
        ax2.plot(dates, daily_vals, marker="o", color="#0891B2", linewidth=2, label="Daily Total (L)")
        ax2.axhline(
            y=CRITICAL_THRESHOLD_LITERS,
            color="#E11D48",
            linestyle="--",
            linewidth=1.5,
            label="250L Critical Limit",
        )
        ax2.set_ylabel("Liters")
        ax2.set_title("Water Usage Calculator — Daily Consumption Trend")
        ax2.tick_params(axis="x", rotation=45)
        ax2.legend()
        ax2.grid(alpha=0.35)
        fig2.tight_layout()
        trend_path = output_dir / "daily_consumption_trend.png"
        fig2.savefig(trend_path, dpi=150)
        plt.close(fig2)
        exported_paths.append(trend_path)

        return exported_paths, ascii_preview
    except ImportError:
        svg_paths = _write_fallback_svg_charts(records, output_dir)
        fallback_note = (
            "[Fallback Notice] Matplotlib not installed; generated standalone SVG charts and ASCII plots.\n\n"
            + ascii_preview
        )
        return svg_paths, fallback_note
