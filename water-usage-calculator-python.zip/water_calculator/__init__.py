"""Project #44: Water Usage Calculator — DataSpark Challenge Python Package."""

from .models import (
    ActivityProfile,
    BulkImportResult,
    ExecutiveSummary,
    WaterRecord,
)
from .engine import (
    ACTIVITY_PROFILES,
    CRITICAL_THRESHOLD_LITERS,
    ELEVATED_THRESHOLD_LITERS,
    calculate_estimated_liters,
    classify_case_type,
    classify_threshold,
    create_water_record,
    next_record_id,
)

__all__ = [
    "ACTIVITY_PROFILES",
    "ActivityProfile",
    "BulkImportResult",
    "CRITICAL_THRESHOLD_LITERS",
    "ELEVATED_THRESHOLD_LITERS",
    "ExecutiveSummary",
    "WaterRecord",
    "calculate_estimated_liters",
    "classify_case_type",
    "classify_threshold",
    "create_water_record",
    "next_record_id",
]
