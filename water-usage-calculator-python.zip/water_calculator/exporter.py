"""Multi-format report exports (Markdown, audit logs, CSV) and bulk legacy CSV import."""

from __future__ import annotations

import csv
import datetime
from pathlib import Path

from .engine import create_water_record, next_record_id
from .models import BulkImportResult, ExecutiveSummary, WaterRecord
from .storage import save_records_csv
from .validation import (
    sanitize_notes,
    validate_activity,
    validate_date,
    validate_household_id,
    validate_quantity,
)


def export_markdown_report(
    summary: ExecutiveSummary,
    records: list[WaterRecord],
    output_path: Path,
) -> Path:
    """Export a structured Markdown executive summary and threshold breach report."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    today_str = datetime.date.today().isoformat()
    lines = [
        "# Water Usage Calculator — Executive Summary Report",
        "",
        f"- **Generated On**: {today_str}",
        f"- **Records Analyzed**: {summary.total_records} ({summary.unique_days} active days)",
        f"- **Total Consumption**: {summary.total_liters:,.1f} L",
        f"- **Daily Average**: {summary.daily_average:,.1f} L/day",
        f"- **Average Per Entry**: {summary.average_per_entry:,.1f} L",
        f"- **Status Counts**: Nominal ({summary.nominal_count}) | Elevated ({summary.elevated_count}) | Critical Breach ({summary.critical_breach_count})",
        "",
        "## Activity Breakdown",
        "| Activity | Entries | Total Liters | Share (%) |",
        "| --- | ---: | ---: | ---: |",
    ]
    for item in summary.by_activity:
        lines.append(
            f"| {item['activity']} | {item['count']} | {item['total_liters']:.1f} L | {item['share_pct']:.1f}% |"
        )

    lines.extend(
        [
            "",
            "## Critical Breach Log (>=250L)",
            "| ID | Date | Household | Activity | Estimated Liters | Notes |",
            "| --- | --- | --- | --- | ---: | --- |",
        ]
    )
    breaches = [r for r in records if r.status == "Critical Breach"]
    if breaches:
        for rec in breaches:
            lines.append(
                f"| {rec.id} | {rec.date} | {rec.household_id} | {rec.activity} | {rec.estimated_liters:.1f} L | {rec.notes} |"
            )
    else:
        lines.append("| - | - | - | - | - | No critical breaches recorded |")

    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return output_path


def export_text_audit_log(
    summary: ExecutiveSummary,
    records: list[WaterRecord],
    output_path: Path,
) -> Path:
    """Export a plain-text audit log containing summary totals, warnings, and record rows."""
    output_path.parent.mkdir(parents=True, exist_ok=True)
    timestamp = datetime.datetime.now().strftime("%Y-%m-%d %H:%M:%S")
    lines = [
        "======================================================================",
        "WATER USAGE CALCULATOR — PLAIN-TEXT AUDIT LOG",
        f"Generated: {timestamp}",
        "======================================================================",
        f"Total Records      : {summary.total_records}",
        f"Total Liters       : {summary.total_liters:.1f} L",
        f"Daily Average      : {summary.daily_average:.1f} L/day",
        f"Critical Breaches  : {summary.critical_breach_count}",
        "",
        "THRESHOLD WARNINGS:",
    ]
    if summary.warnings:
        lines.extend([f"  * {w}" for w in summary.warnings])
    else:
        lines.append("  * None")

    lines.extend(["", "RECORD LEDGER:"])
    for rec in records:
        lines.append(
            f"{rec.id} | {rec.date} | {rec.household_id} | {rec.activity:<11} | "
            f"{rec.quantity:.1f} {rec.unit:<7} | {rec.estimated_liters:.1f} L | {rec.status} | {rec.notes}"
        )

    output_path.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return output_path


def export_standard_csv(records: list[WaterRecord], output_path: Path) -> Path:
    """Export standardized CSV file for external spreadsheet review."""
    save_records_csv(output_path, records)
    return output_path


def bulk_import_csv(
    csv_path: Path,
    existing_records: list[WaterRecord],
) -> BulkImportResult:
    """Ingest legacy CSV files with automatic validation and row-by-row error logs."""
    error_logs: list[str] = []
    imported: list[WaterRecord] = []
    working_records = list(existing_records)

    try:
        with csv_path.open("r", encoding="utf-8", newline="") as handle:
            reader = csv.reader(handle)
            rows = list(reader)
    except FileNotFoundError:
        return BulkImportResult(
            imported_count=0,
            skipped_count=0,
            records=[],
            error_logs=[f"File not found: '{csv_path}'."],
        )
    except (csv.Error, OSError) as err:
        return BulkImportResult(
            imported_count=0,
            skipped_count=0,
            records=[],
            error_logs=[f"Failed to read CSV '{csv_path}': {err}"],
        )

    if not rows:
        return BulkImportResult(0, 0, [], ["CSV file is empty."])

    # Detect optional header row
    start_idx = 0
    first_lower = [cell.strip().lower() for cell in rows[0]]
    if "date" in first_lower and "activity" in first_lower:
        start_idx = 1

    for row_number, raw_row in enumerate(rows[start_idx:], start=start_idx + 1):
        if not any(cell.strip() for cell in raw_row):
            continue

        try:
            # Support both compact 5-column (date,hh,activity,qty,notes) and full 11-column schema
            if len(raw_row) >= 11:
                date_raw, hh_raw, act_raw, qty_raw = raw_row[1], raw_row[2], raw_row[3], raw_row[4]
                notes_raw = raw_row[10]
            elif len(raw_row) >= 4:
                date_raw, hh_raw, act_raw, qty_raw = raw_row[0], raw_row[1], raw_row[2], raw_row[3]
                notes_raw = raw_row[4] if len(raw_row) > 4 else ""
            else:
                raise ValueError("Expected at least 4 CSV columns (date, household_id, activity, quantity).")

            clean_date = validate_date(date_raw)
            clean_hh = validate_household_id(hh_raw)
            clean_act = validate_activity(act_raw)
            clean_qty = validate_quantity(qty_raw, clean_act)
            clean_notes = sanitize_notes(notes_raw, default=f"Bulk imported {clean_act} entry")

            rec_id = next_record_id(working_records)
            new_rec = create_water_record(
                record_id=rec_id,
                date_str=clean_date,
                household_id=clean_hh,
                activity=clean_act,
                quantity=clean_qty,
                notes=clean_notes,
            )
            working_records.append(new_rec)
            imported.append(new_rec)
        except ValueError as err:
            error_logs.append(f"Row {row_number}: {err}")

    return BulkImportResult(
        imported_count=len(imported),
        skipped_count=len(error_logs),
        records=imported,
        error_logs=error_logs,
    )
