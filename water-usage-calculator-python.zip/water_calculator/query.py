"""Record querying, sorting, pagination, and fixed-width terminal table formatting."""

from __future__ import annotations

import math

from .models import WaterRecord


def filter_records(
    records: list[WaterRecord],
    keyword: str = "",
    activity: str | None = None,
    household_id: str | None = None,
    status: str | None = None,
    case_type: str | None = None,
) -> list[WaterRecord]:
    """Filter WaterRecord collection by keyword and structured attributes."""
    q = keyword.strip().lower()
    act_filter = activity.strip().lower() if activity else None
    hh_filter = household_id.strip().upper() if household_id else None
    status_filter = status.strip().lower() if status else None
    case_filter = case_type.strip().lower() if case_type else None

    results: list[WaterRecord] = []
    for rec in records:
        if act_filter and rec.activity.lower() != act_filter:
            continue
        if hh_filter and rec.household_id.upper() != hh_filter:
            continue
        if status_filter and rec.status.lower() != status_filter:
            continue
        if case_filter and rec.case_type.lower() != case_filter:
            continue
        if q:
            haystack = " ".join(
                [rec.id, rec.date, rec.household_id, rec.activity, rec.status, rec.case_type, rec.notes]
            ).lower()
            if q not in haystack:
                continue
        results.append(rec)
    return results


def sort_records(
    records: list[WaterRecord],
    sort_by: str = "date",
    descending: bool = True,
) -> list[WaterRecord]:
    """Return a sorted copy of WaterRecord objects by a specified field."""
    valid_keys = {
        "id": lambda r: r.id,
        "date": lambda r: r.date,
        "household_id": lambda r: r.household_id,
        "activity": lambda r: r.activity,
        "quantity": lambda r: r.quantity,
        "estimated_liters": lambda r: r.estimated_liters,
        "status": lambda r: r.status,
    }
    key_fn = valid_keys.get(sort_by, valid_keys["date"])
    return sorted(records, key=key_fn, reverse=descending)


def paginate_records(
    records: list[WaterRecord],
    page: int = 1,
    page_size: int = 12,
) -> tuple[list[WaterRecord], int, int]:
    """Slice records into fixed-size pages and return (items, safe_page, total_pages)."""
    size = max(1, page_size)
    total_pages = max(1, math.ceil(len(records) / size))
    safe_page = min(max(1, page), total_pages)
    start = (safe_page - 1) * size
    return records[start : start + size], safe_page, total_pages


def _truncate(text: str, width: int) -> str:
    if len(text) <= width:
        return text
    return text[: max(1, width - 3)] + "..."


def format_records_table(
    records: list[WaterRecord],
    page: int = 1,
    page_size: int = 12,
    use_ansi: bool = True,
) -> str:
    """Format WaterRecord rows into a fixed-width aligned terminal table with pagination."""
    if not records:
        return "  (No matching records found.)"

    items, safe_page, total_pages = paginate_records(records, page=page, page_size=page_size)

    cyan = "\033[96m" if use_ansi else ""
    green = "\033[92m" if use_ansi else ""
    yellow = "\033[93m" if use_ansi else ""
    red = "\033[91m" if use_ansi else ""
    bold = "\033[1m" if use_ansi else ""
    reset = "\033[0m" if use_ansi else ""

    header = (
        f"{'ID':<7} | {'Date':<10} | {'HH':<5} | {'Activity':<11} | "
        f"{'Input':>11} | {'Liters':>8} | {'Case':<14} | {'Status':<15} | {'Notes':<26}"
    )
    divider = "-" * len(header)
    lines = [f"{bold}{cyan}{header}{reset}", divider]

    for rec in items:
        qty_str = f"{rec.quantity:.1f} {rec.unit}"
        liters_str = f"{rec.estimated_liters:.1f} L"
        status_color = (
            red
            if rec.status == "Critical Breach"
            else yellow
            if rec.status == "Elevated"
            else green
        )
        row = (
            f"{rec.id:<7} | {rec.date:<10} | {rec.household_id:<5} | {rec.activity:<11} | "
            f"{qty_str:>11} | {liters_str:>8} | {_truncate(rec.case_type, 14):<14} | "
            f"{status_color}{rec.status:<15}{reset} | {_truncate(rec.notes, 26):<26}"
        )
        lines.append(row)

    lines.append(divider)
    lines.append(
        f"Showing {len(items)} of {len(records)} records | Page {safe_page}/{total_pages}"
    )
    return "\n".join(lines)
