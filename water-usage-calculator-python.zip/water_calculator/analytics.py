"""Executive summary aggregation and threshold warning indicator module."""

from __future__ import annotations

import datetime
from collections import defaultdict

from .engine import ACTIVITY_PROFILES, CRITICAL_THRESHOLD_LITERS, ELEVATED_THRESHOLD_LITERS
from .models import ExecutiveSummary, WaterRecord


def compute_executive_summary(
    records: list[WaterRecord],
    reference_date: datetime.date | None = None,
) -> ExecutiveSummary:
    """Compute totals, averages, category/household rollups, and threshold warnings."""
    if not records:
        return ExecutiveSummary(
            total_records=0,
            unique_days=0,
            total_liters=0.0,
            average_per_entry=0.0,
            daily_average=0.0,
            nominal_count=0,
            elevated_count=0,
            critical_breach_count=0,
            by_activity=[],
            by_household=[],
            daily_totals=[],
            warnings=["No records available in store."],
        )

    total_liters = round(sum(r.estimated_liters for r in records), 1)
    unique_dates = sorted({r.date for r in records})
    unique_days = len(unique_dates)
    avg_entry = round(total_liters / len(records), 1)
    daily_avg = round(total_liters / max(1, unique_days), 1)

    nominal_count = sum(1 for r in records if r.status == "Nominal")
    elevated_count = sum(1 for r in records if r.status == "Elevated")
    critical_count = sum(1 for r in records if r.status == "Critical Breach")

    # Activity aggregation
    act_totals: dict[str, float] = defaultdict(float)
    act_counts: dict[str, int] = defaultdict(int)
    for rec in records:
        act_totals[rec.activity] += rec.estimated_liters
        act_counts[rec.activity] += 1

    by_activity = []
    for act in ACTIVITY_PROFILES:
        liters = round(act_totals[act], 1)
        share = round((liters / total_liters) * 100.0, 1) if total_liters > 0 else 0.0
        by_activity.append(
            {
                "activity": act,
                "count": act_counts[act],
                "total_liters": liters,
                "share_pct": share,
            }
        )
    by_activity.sort(key=lambda item: item["total_liters"], reverse=True)

    # Household aggregation
    hh_records: dict[str, list[WaterRecord]] = defaultdict(list)
    for rec in records:
        hh_records[rec.household_id].append(rec)

    by_household = []
    for hh_id in sorted(hh_records.keys()):
        rows = hh_records[hh_id]
        hh_total = round(sum(r.estimated_liters for r in rows), 1)
        hh_avg = round(hh_total / len(rows), 1)
        hh_breaches = sum(1 for r in rows if r.status == "Critical Breach")
        latest_date = max(r.date for r in rows)
        by_household.append(
            {
                "household_id": hh_id,
                "entries": len(rows),
                "total_liters": hh_total,
                "avg_per_entry": hh_avg,
                "critical_breaches": hh_breaches,
                "latest_date": latest_date,
                "status": (
                    "Critical Breach"
                    if hh_breaches >= 2
                    else "Elevated"
                    if hh_breaches == 1
                    else "Nominal"
                ),
            }
        )

    # Daily totals
    day_totals: dict[str, float] = defaultdict(float)
    for rec in records:
        day_totals[rec.date] += rec.estimated_liters
    daily_totals = [
        {"date": d, "total_liters": round(day_totals[d], 1)} for d in sorted(day_totals.keys())
    ]

    # Threshold Warning Indicators (Critical limit breaches, anomalous spikes, overdue audits)
    warnings: list[str] = []
    for rec in records:
        if rec.estimated_liters >= CRITICAL_THRESHOLD_LITERS:
            warnings.append(
                f"[CRITICAL BREACH] {rec.id} ({rec.date}, {rec.household_id}, {rec.activity}): "
                f"{rec.estimated_liters:.1f} L >= {CRITICAL_THRESHOLD_LITERS:.0f} L limit."
            )
        elif avg_entry > 0 and rec.estimated_liters > avg_entry * 2.0 and rec.estimated_liters >= ELEVATED_THRESHOLD_LITERS:
            warnings.append(
                f"[ANOMALY SPIKE] {rec.id} ({rec.household_id}): {rec.estimated_liters:.1f} L "
                f"is >2x dataset mean ({avg_entry:.1f} L)."
            )

    ref_day = reference_date or datetime.date.fromisoformat(unique_dates[-1])
    for hh in by_household:
        try:
            last_dt = datetime.date.fromisoformat(hh["latest_date"])
            gap_days = (ref_day - last_dt).days
            if gap_days > 7:
                warnings.append(
                    f"[OVERDUE CHECK-IN] {hh['household_id']}: Last logged {hh['latest_date']} ({gap_days} days ago)."
                )
        except ValueError:
            continue

    return ExecutiveSummary(
        total_records=len(records),
        unique_days=unique_days,
        total_liters=total_liters,
        average_per_entry=avg_entry,
        daily_average=daily_avg,
        nominal_count=nominal_count,
        elevated_count=elevated_count,
        critical_breach_count=critical_count,
        by_activity=by_activity,
        by_household=by_household,
        daily_totals=daily_totals,
        warnings=warnings,
    )


def format_executive_summary(summary: ExecutiveSummary, use_ansi: bool = True) -> str:
    """Render formatted multi-section executive summary tables for terminal output."""
    bold = "\033[1m" if use_ansi else ""
    cyan = "\033[96m" if use_ansi else ""
    yellow = "\033[93m" if use_ansi else ""
    red = "\033[91m" if use_ansi else ""
    reset = "\033[0m" if use_ansi else ""

    lines = [
        f"{bold}{cyan}=== EXECUTIVE SUMMARY REPORT ==={reset}",
        f"Total Records      : {summary.total_records} ({summary.unique_days} active days)",
        f"Total Water Used   : {summary.total_liters:,.1f} L",
        f"Daily Average      : {summary.daily_average:,.1f} L/day",
        f"Average Per Entry  : {summary.average_per_entry:,.1f} L",
        f"Status Breakdown   : Nominal={summary.nominal_count} | Elevated={summary.elevated_count} | Critical Breach={summary.critical_breach_count}",
        "",
        f"{bold}Activity Distribution{reset}",
        f"{'Activity':<13} | {'Entries':>7} | {'Total Liters':>12} | {'Share':>7}",
        "-" * 48,
    ]
    for item in summary.by_activity:
        lines.append(
            f"{item['activity']:<13} | {item['count']:>7} | {item['total_liters']:>10.1f} L | {item['share_pct']:>6.1f}%"
        )

    lines.extend(
        [
            "",
            f"{bold}Household Breakdown{reset}",
            f"{'Household':<10} | {'Entries':>7} | {'Total Liters':>12} | {'Avg/Entry':>10} | {'Breaches':>8} | {'Status':<15}",
            "-" * 76,
        ]
    )
    for hh in summary.by_household:
        lines.append(
            f"{hh['household_id']:<10} | {hh['entries']:>7} | {hh['total_liters']:>10.1f} L | "
            f"{hh['avg_per_entry']:>8.1f} L | {hh['critical_breaches']:>8} | {hh['status']:<15}"
        )

    if summary.warnings:
        lines.extend(["", f"{bold}{yellow}Threshold Warning Indicators ({len(summary.warnings)}){reset}"])
        for warning in summary.warnings[:10]:
            color = red if "CRITICAL" in warning else yellow
            lines.append(f"  {color}! {warning}{reset}")
        if len(summary.warnings) > 10:
            lines.append(f"  ... and {len(summary.warnings) - 10} more warnings.")

    return "\n".join(lines)
