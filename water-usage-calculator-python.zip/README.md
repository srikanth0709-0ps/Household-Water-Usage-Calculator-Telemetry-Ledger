# Project #44: Water Usage Calculator (DataSpark Challenge)

**Domain:** Environment & Sustainability | **Stack:** Python 3.10+ CLI + Interactive Web Companion

## Overview
Water Usage Calculator is a lightweight, fault-tolerant Python application engineered to estimate household water consumption from daily domestic activity inputs, enforce strict defensive input validation, persist records reliably in local JSON and CSV files, and produce executive summaries, threshold warnings, and visual trend charts.

## Implemented Features

### Core Modules
1. **Interactive Terminal Interface (`water_calculator/cli.py`, `main.py`)**: ANSI-formatted menu-driven CLI with branded welcome screen, guided entry prompts, and clean dispatch loop.
2. **Defensive Input Validation (`water_calculator/validation.py`)**: Centralized regex, type-cast, and domain-range prompt wrappers rejecting blank, negative, non-numeric, or out-of-bounds inputs cleanly.
3. **Core Business Logic Engine (`water_calculator/engine.py`)**: Calibrated per-activity multipliers (`Shower`, `Laundry`, `Dishwashing`, `Garden`, `Kitchen`, `Toilet`) and automatic threshold classification (`Nominal`, `Elevated`, `Critical Breach`).
4. **Local Data Persistence (`water_calculator/storage.py`)**: Automatic JSON/CSV serialization with `try-except` recovery for `FileNotFoundError` and `JSONDecodeError`.
5. **Record Query & Search (`water_calculator/query.py`)**: Keyword, category, household, and status filtering paired with fixed-width tabular formatting and pagination.
6. **Executive Summary Generation (`water_calculator/analytics.py`)**: Aggregates total liters, daily averages, activity shares, household rollups, and threshold warning indicators.
7. **Visual Data Plotting (`water_calculator/plotting.py`)**: Exports Matplotlib bar/trend PNG charts with graceful `ImportError` fallback to standalone SVG and ASCII terminal plots.

### Stretch Modules
- **Multi-Format Summary Export (`water_calculator/exporter.py`)**: Generates Markdown reports (`.md`), plain-text audit logs (`.txt`), and standardized CSV exports.
- **Threshold Warning Indicators**: Flags critical breaches (`>= 250 L`), anomaly spikes (`> 2x` dataset mean), and overdue household check-ins (`> 7 days`).
- **Bulk Legacy CSV Import**: Validates external CSV datasets row-by-row and outputs an explicit error audit log while committing valid records.
- **Interactive Web Dashboard (`src/`)**: Colourful React + TypeScript GUI companion matching the exact same domain models, flow-rate formulas, validation rules, charts, and 36-record dataset.

## Running the Python CLI & Tests

```bash
# Run interactive terminal application
python3 main.py

# Non-interactive executive summary, reports, and charts
python3 main.py --summary --export --plot

# Run automated unit test suite
python3 -m unittest discover -s tests -v
```

## Optional Matplotlib Installation

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
```
