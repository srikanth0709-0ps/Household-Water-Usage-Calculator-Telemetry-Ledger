"""Comprehensive unit tests for Project #44: Water Usage Calculator."""

from __future__ import annotations

import json
import tempfile
import unittest
from pathlib import Path

from water_calculator.analytics import compute_executive_summary, format_executive_summary
from water_calculator.engine import (
    calculate_estimated_liters,
    classify_case_type,
    classify_threshold,
    create_water_record,
    next_record_id,
)
from water_calculator.exporter import (
    bulk_import_csv,
    export_markdown_report,
    export_standard_csv,
    export_text_audit_log,
)
from water_calculator.plotting import export_visual_charts, render_ascii_charts
from water_calculator.query import filter_records, format_records_table, paginate_records, sort_records
from water_calculator.storage import (
    SAMPLE_CSV_PATH,
    SAMPLE_JSON_PATH,
    load_records_csv,
    load_records_json,
    save_records_csv,
    save_records_json,
)
from water_calculator.validation import (
    prompt_with_validator,
    sanitize_notes,
    validate_activity,
    validate_date,
    validate_household_id,
    validate_quantity,
)


class TestWaterUsageCalculator(unittest.TestCase):
    """End-to-end verification of calculation, validation, persistence, analytics, and exports."""

    def test_sample_datasets_exist_with_36_records(self) -> None:
        json_records, json_notices = load_records_json(SAMPLE_JSON_PATH, seed_fallback_path=SAMPLE_JSON_PATH)
        csv_records, csv_notices = load_records_csv(SAMPLE_CSV_PATH)
        self.assertEqual(len(json_records), 36)
        self.assertEqual(len(csv_records), 36)
        self.assertEqual(json_notices, [])
        self.assertEqual(csv_notices, [])

    def test_calculation_and_threshold_classification(self) -> None:
        self.assertEqual(calculate_estimated_liters("Shower", 10), 95.0)
        self.assertEqual(calculate_estimated_liters("Laundry", 3), 162.0)
        self.assertEqual(calculate_estimated_liters("Garden", 20), 280.0)

        self.assertEqual(classify_threshold(95.0), "Nominal")
        self.assertEqual(classify_threshold(140.0), "Elevated")
        self.assertEqual(classify_threshold(250.0), "Critical Breach")

        self.assertEqual(classify_case_type("Shower", 1.0, 9.5), "Boundary")
        self.assertEqual(classify_case_type("Garden", 45.0, 630.0), "Edge Condition")
        self.assertEqual(classify_case_type("Shower", 8.0, 76.0), "Normal")

    def test_defensive_validation_rejects_bad_inputs(self) -> None:
        self.assertEqual(validate_date("2026-11-24"), "2026-11-24")
        with self.assertRaises(ValueError):
            validate_date("2026-02-30")
        with self.assertRaises(ValueError):
            validate_date("")

        self.assertEqual(validate_household_id("hh-02"), "HH-02")
        with self.assertRaises(ValueError):
            validate_household_id("BAD-ID")
        with self.assertRaises(ValueError):
            validate_household_id("HH-00")

        self.assertEqual(validate_activity("1"), "Shower")
        self.assertEqual(validate_activity("garden"), "Garden")
        with self.assertRaises(ValueError):
            validate_activity("SwimmingPool")

        self.assertEqual(validate_quantity("12.5", "Shower"), 12.5)
        with self.assertRaises(ValueError):
            validate_quantity("-5", "Shower")
        with self.assertRaises(ValueError):
            validate_quantity("abc", "Shower")
        with self.assertRaises(ValueError):
            validate_quantity("999", "Shower")

        self.assertEqual(sanitize_notes("  line1\nline2  "), "line1 line2")

    def test_centralized_prompt_loop_recovers_after_invalid_attempts(self) -> None:
        inputs = iter(["abc", "-10", "15"])
        outputs: list[str] = []
        result = prompt_with_validator(
            "Qty: ",
            lambda raw: validate_quantity(raw, "Shower"),
            input_fn=lambda _: next(inputs),
            output_fn=outputs.append,
        )
        self.assertEqual(result, 15.0)
        self.assertEqual(len(outputs), 2)
        self.assertIn("Validation Error", outputs[0])

    def test_json_and_csv_persistence_and_corruption_recovery(self) -> None:
        with tempfile.TemporaryDirectory() as tmp:
            tmp_dir = Path(tmp)
            json_file = tmp_dir / "store.json"
            csv_file = tmp_dir / "store.csv"

            # Corrupted JSON recovery
            json_file.write_text("{corrupted json", encoding="utf-8")
            recovered, notices = load_records_json(json_file, seed_fallback_path=SAMPLE_JSON_PATH)
            self.assertEqual(len(recovered), 36)
            self.assertTrue(any("Corrupted" in n for n in notices))

            # Round-trip add + save + reload
            new_id = next_record_id(recovered)
            self.assertEqual(new_id, "WU-137")
            rec = create_water_record(new_id, "2026-11-24", "HH-01", "Shower", 10, "Persist check")
            updated = [rec, *recovered]
            save_records_json(json_file, updated)
            save_records_csv(csv_file, updated)

            reloaded_json, _ = load_records_json(json_file, seed_fallback_path=SAMPLE_JSON_PATH)
            reloaded_csv, _ = load_records_csv(csv_file)
            self.assertEqual(len(reloaded_json), 37)
            self.assertEqual(len(reloaded_csv), 37)
            self.assertEqual(reloaded_json[0].id, "WU-137")
            self.assertEqual(reloaded_csv[0].estimated_liters, 95.0)

    def test_query_pagination_and_table_formatting(self) -> None:
        records, _ = load_records_json(SAMPLE_JSON_PATH, seed_fallback_path=SAMPLE_JSON_PATH)
        breaches = filter_records(records, status="Critical Breach")
        self.assertGreaterEqual(len(breaches), 5)

        sorted_desc = sort_records(breaches, sort_by="estimated_liters", descending=True)
        self.assertGreaterEqual(sorted_desc[0].estimated_liters, sorted_desc[-1].estimated_liters)

        page_items, safe_page, total_pages = paginate_records(records, page=2, page_size=12)
        self.assertEqual(len(page_items), 12)
        self.assertEqual(safe_page, 2)
        self.assertEqual(total_pages, 3)

        table_text = format_records_table(records, page=1, page_size=12, use_ansi=False)
        self.assertIn("Page 1/3", table_text)

    def test_analytics_plotting_exports_and_bulk_import(self) -> None:
        records, _ = load_records_json(SAMPLE_JSON_PATH, seed_fallback_path=SAMPLE_JSON_PATH)
        summary = compute_executive_summary(records)
        self.assertEqual(summary.total_records, 36)
        self.assertGreater(summary.total_liters, 4000.0)
        self.assertGreater(len(summary.warnings), 0)

        formatted = format_executive_summary(summary, use_ansi=False)
        self.assertIn("EXECUTIVE SUMMARY REPORT", formatted)

        ascii_plot = render_ascii_charts(records)
        self.assertIn("VISUAL WATER USAGE DISTRIBUTION", ascii_plot)

        with tempfile.TemporaryDirectory() as tmp:
            tmp_dir = Path(tmp)
            chart_paths, _ = export_visual_charts(records, tmp_dir / "charts")
            self.assertEqual(len(chart_paths), 2)
            for p in chart_paths:
                self.assertTrue(p.exists())

            md = export_markdown_report(summary, records, tmp_dir / "report.md")
            txt = export_text_audit_log(summary, records, tmp_dir / "audit.txt")
            csv_out = export_standard_csv(records, tmp_dir / "out.csv")
            self.assertTrue(md.exists() and txt.exists() and csv_out.exists())

            # Bulk import with mixed valid and invalid rows
            legacy_csv = tmp_dir / "legacy.csv"
            legacy_csv.write_text(
                "date,householdId,activity,quantity,notes\n"
                "2026-11-24,HH-02,Laundry,3,Valid bulk row\n"
                "2026-11-24,BAD_ID,Shower,-5,Invalid row\n"
                "2026-11-24,HH-04,Garden,15,Second valid row\n",
                encoding="utf-8",
            )
            bulk_result = bulk_import_csv(legacy_csv, records)
            self.assertEqual(bulk_result.imported_count, 2)
            self.assertEqual(bulk_result.skipped_count, 1)
            self.assertEqual(len(bulk_result.error_logs), 1)


if __name__ == "__main__":
    unittest.main()
